from pydantic import BaseModel

class Login(BaseModel):
    username: str
    password: str
    
class TokenSchema(BaseModel):
    access_token: str
    # refresh_token: str
        
class TokenPayload(BaseModel):
    sub: str = None
    exp: int = None
    
class ChatModel(BaseModel):
    command: str