import pymongo

APIKEY = "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"
CONNECTION_STRING = 'Driver={SQL Server};Server=DESKTOP-LD6Q13P;Database=ChatGpt;User=sa;Password=;'


MONGO_CONNECTION = pymongo.MongoClient("mongodb://localhost:27017/")
