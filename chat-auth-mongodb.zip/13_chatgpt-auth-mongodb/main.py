import os
import pymongo
from colorama import Fore
from fastapi import FastAPI, status, HTTPException, Depends
from Database.constants import APIKEY, MONGO_CONNECTION
from Models.schemas import ChatModel, TokenSchema, Login
from langchain.chains import ConversationalRetrievalChain
from langchain.chat_models import ChatOpenAI
from langchain.document_loaders import DirectoryLoader
from langchain.indexes import VectorstoreIndexCreator
from langchain.document_loaders import UnstructuredURLLoader
from apps.utils import get_hashed_password, verify_password, create_access_token
from Services.LinkServices import GetURL
from apps.deps import authentication

# uvicorn main:app --reload

app = FastAPI()

@app.post('/login', summary="login", response_model=TokenSchema)
async def login(data: Login): 
    _username = data.username    
    mydb = MONGO_CONNECTION["ChatGpt"]
    collection = mydb["Users"]
    result = collection.find_one({'username':_username})

    if result is not None:                    
        password = result['password']        
        hashed_pass = password
        if not verify_password(data.password, hashed_pass):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Incorrect username or password"
            )
        
        return {            
            "access_token": create_access_token(result['username'])            
        }

    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Incorrect username or password"
        )


@app.post('/signup', summary="create new user")
async def create_user(data: Login, user: str = Depends(authentication)):
    
    if user == "orash":
        print(Fore.MAGENTA,'--->' ,user)
        
        mydb = MONGO_CONNECTION["ChatGpt"]
        collection = mydb["Users"]
        duplicate = collection.find_one({'username': data.username})
        
        # check duplicate
        if duplicate is not None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="User with this username already exist."
            )
            
        password_hash = get_hashed_password(data.password)   
        data_dict = {
            "username": data.username,
            "password": password_hash
        }
        
        row = collection.insert_one(data_dict)   
        # row.inserted_id 

        # get user list
        users=[]    
        user_list = collection.find({})
        
        for user in user_list:
            user.pop('_id')
            user.pop('password')
            users.append(user)
        
        return users    
    else:
        return {"response":"You have not access to create user."}
        


@app.post("/orashai/url")
async def create_item(chat: ChatModel, user:str = Depends(authentication)):    
    os.environ["OPENAI_API_KEY"] = APIKEY
    query = None
    query = chat.command

    link_list = GetURL()        
        
    loader = UnstructuredURLLoader(urls= link_list) #URL            
    index = VectorstoreIndexCreator().from_loaders([loader])

    chain = ConversationalRetrievalChain.from_llm(         
      llm = ChatOpenAI(model="gpt-3.5-turbo"),
      retriever = index.vectorstore.as_retriever(search_kwargs={"k": 1})
    )

    chat_history = []
 
    result = chain({"question": query, "chat_history": chat_history})  
    res = result['answer']
    chat_history.append((query, result['answer'])) 
    query = None
    return{"response": res}


@app.post("/orashai/data")
async def create_item(chat: ChatModel, user:str = Depends(authentication)):    
    os.environ["OPENAI_API_KEY"] = APIKEY
    PERSIST = False
    query = None
    query = chat.command
    
    loader = DirectoryLoader("data/")             
    index = VectorstoreIndexCreator().from_loaders([loader])

    chain = ConversationalRetrievalChain.from_llm(         
      llm = ChatOpenAI(model="gpt-3.5-turbo"),
      retriever = index.vectorstore.as_retriever(search_kwargs={"k": 1})
    )

    chat_history = []
 
    result = chain({"question": query, "chat_history": chat_history})  
    res = result['answer']
    chat_history.append((query, result['answer'])) 
    query = None
    return{"response": res}