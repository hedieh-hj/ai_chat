import pyodbc
from Database.constants import MONGO_CONNECTION
from colorama import Fore

def GetURL():
    mydb = MONGO_CONNECTION["ChatGpt"]
    collection = mydb["Links"]
    result = collection.find({})
    links = []        
    
    for row in result:                
        links.append(row['link'])
    
    return links  