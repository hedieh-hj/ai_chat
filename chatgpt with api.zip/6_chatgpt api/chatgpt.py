import os
import sys
from langchain.chains import ConversationalRetrievalChain, RetrievalQA
from langchain.chat_models import ChatOpenAI
from langchain.document_loaders import DirectoryLoader, TextLoader
from langchain.embeddings import OpenAIEmbeddings
from langchain.indexes import VectorstoreIndexCreator
from langchain.indexes.vectorstore import VectorStoreIndexWrapper
from langchain.llms import OpenAI
from langchain.vectorstores import Chroma
from langchain.document_loaders import UnstructuredURLLoader
from pydantic import BaseModel
import constants
from typing import Union
from fastapi import FastAPI

app = FastAPI()

class ChatModel(BaseModel):
    input: str


@app.post("/chatgpt")
async def create_item(chatmodel: ChatModel):    
    os.environ["OPENAI_API_KEY"] = constants.APIKEY
    PERSIST = False
    query = None
    query = chatmodel.input

    loader = DirectoryLoader("data/")             
    index = VectorstoreIndexCreator().from_loaders([loader])   

    chain = ConversationalRetrievalChain.from_llm(         
      llm = ChatOpenAI(model="gpt-3.5-turbo"),
      retriever = index.vectorstore.as_retriever(search_kwargs={"k": 1})
    )

    chat_history = []
 
    result = chain({"question": query, "chat_history": chat_history})  
    res = result['answer']
    chat_history.append((query, result['answer'])) 
    query = None
    return{"response":res}






    """ using URL list
    urls = [
      "https://orash.ir/",
      "https://en.wikipedia.org/wiki/Nutella",
    ]            
    loader = UnstructuredURLLoader(urls=urls)
    
    # loader = TextLoader("data/data2.txt")
    """