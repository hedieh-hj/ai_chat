# Replace with your own OpenAI API Key https://platform.openai.com/account/api-keys
# and rename this file to constants.py.
APIKEY = "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"
