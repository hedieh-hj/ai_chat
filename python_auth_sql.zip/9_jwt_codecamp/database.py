

connection_string = 'Driver={SQL Server};Server=DESKTOP-LD6Q13P;Database=ChatGpt;User=aa;Password=123456;'


# Driver={Devart ODBC Driver for SQL Server}
# conn = pyodbc.connect(connection_string)
# cursor = database.cursor
# cursor.execute("SELECT * FROM YourTable")
# rows = cursor.fetchone()  
# rows = cursor.fetall()  
# cursor.close()
# conn.close()