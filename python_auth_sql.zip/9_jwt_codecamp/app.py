from fastapi import FastAPI, status, HTTPException, Depends
from fastapi.responses import RedirectResponse
from deps import auth
from schemas import SystemUser, UserOut, UserAuth, TokenSchema, Login
from fastapi.security import OAuth2PasswordRequestForm
from utils import get_hashed_password, verify_password
from uuid import uuid4
import utils
import database
import pyodbc
import json
from colorama import Fore

app = FastAPI()

@app.get('/users', summary='get users')  # response_model=UserOut
async def get_users(user: str = Depends(auth)):
    users =[]  
      
    # connection    
    conn = pyodbc.connect(database.connection_string)        
    cursor = conn.cursor()     
    
    # get users
    cursor.execute("SELECT id,email FROM users")        
    records = cursor.fetchall()             

    for row in records:
        data_dict = {
        "id": row[0],
        "email": row[1]
        }
        users.append(data_dict)  
    
    cursor.close()
    conn.close()

    return users
    

@app.post('/signup', summary="create new user")
async def create_user(data: UserAuth):
    users=[]
    # connection
    conn = pyodbc.connect(database.connection_string)
    cursor = conn.cursor() 
    
    # search users find duplicate email
    cursor.execute("SELECT id,email FROM users")
    rows = cursor.fetchall()

    for row in rows:                    
        if(row[1] == data.email):
            raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User with this email already exist"
        )
    
    # insert
    insert_query = "INSERT INTO users (email, password) VALUES (?, ?)"
    values = (data.email, get_hashed_password(data.password))

    cursor.execute(insert_query, values)
    conn.commit()

    # get users
    cursor.execute("SELECT id,email FROM users")        
    records = cursor.fetchall()             

    for row in records:
        data_dict = {
        "id": row[0],
        "email": row[1]
        }
        users.append(data_dict) 

    cursor.close()
    conn.close() 

    return users


@app.post('/login', summary="login with jwt token!", response_model=TokenSchema)
async def login(data: Login): #data: OAuth2PasswordRequestForm = Depends()
    username = data.username
    # connection
    conn = pyodbc.connect(database.connection_string)
    cursor = conn.cursor() 
    query = f"SELECT * FROM users WHERE email = '{username}'"
    cursor.execute(query)
    result = cursor.fetchone()

    if result is not None:     
        print(Fore.CYAN,'login result:', result)
        id,email,password = result    
        hashed_pass = password
        if not verify_password(data.password, hashed_pass):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Incorrect email or password"
            )
        
        return {            
            "access_token": utils.create_access_token(result[1]),
            # "refresh_token": utils.create_refresh_token(result[1]),
        }

    else:
        print(Fore.CYAN,'login result error:', result)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Incorrect email or password"
        )


@app.get('/test', summary='test auth') #response_model=UserOut
async def test(user: str = Depends(auth)): #user: SystemUser = Depends(auth)        
    return 'hiiiiiiii'
